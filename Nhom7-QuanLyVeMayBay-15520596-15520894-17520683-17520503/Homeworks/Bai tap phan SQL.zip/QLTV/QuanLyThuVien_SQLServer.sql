create database QLTV
use QLTV

create table DocGia
(
	madocgia smallint primary key,
	ho nvarchar(15),
	tenlot nvarchar(15),
	ten nvarchar(15),
	ngaysinh smalldatetime,
	constraint treEm_docGia_fk foreign key(madocgia) reference key TreEm(madocgia),
    	constraint nguoiLon_docGia_fk foreign key(madocgia) reference key NguoiLon(madocgia),
)

create table NguoiLon
(
	madocgia smallint primary key, 
	foreign key(madocgia) references DocGia(madocgia),

	sonha nvarchar(15),
	duong nvarchar(63),
	quan nvarchar(20),
	dienthoai nvarchar(10),
	hansd smalldatetime
)

create table TreEm
(
	madocgia smallint primary key,
	foreign key(madocgia) references DocGia(madocgia),

	madocgianguoilon smallint references NguoiLon(madocgia)
)

create table TuaSach
(
	matuasach int primary key,
	tuasach nvarchar(63),
	tacgia nvarchar(31),
	tomtat nvarchar(222)
)

create table DauSach
(
	isbn int primary key,
	matuasach int references TuaSach(matuasach),
	ngonngu nvarchar(15),
	bia nvarchar(15),
	trangthai nvarchar(1),
	constraint dauSach_TuaSach_fk foreign key(matuasach) reference key TuaSach(matuasach),
)

create table CuonSach
(
	isbn int references DauSach(isbn),
	macuonsach smallint,
	tinhtrang nvarchar(1),

	primary key(isbn,macuonsach)
)

create table DangKy
(
	isbn int references DauSach(isbn),
	madocgia smallint references DocGia(madocgia),
	ngaygiodk smalldatetime,
	ghichu nvarchar(255),

	primary key(isbn,madocgia)
)

create table Muon
(
	isbn int,
	macuonsach smallint,
	madocgia smallint references DocGia(madocgia),
	ngaygiomuon smalldatetime,
	ngayhethan smalldatetime,

	primary key(isbn,macuonsach),
	foreign key(isbn,macuonsach) references CuonSach(isbn,macuonsach)
)

create table QuaTrinhMuon
(
	isbn int,
	macuonsach smallint,
	ngaygiomuon smalldatetime,
	madocgia smallint references DocGia(madocgia),
	ngayhethan smalldatetime,
	ngaytra smalldatetime,
	tienmuon money,
	tiendatra money,
	tiendatcoc money,
	ghichu nvarchar(255),

	primary key(isbn,macuonsach,ngaygiomuon),
	foreign key(isbn,macuonsach) references CuonSach(isbn,macuonsach)
)

