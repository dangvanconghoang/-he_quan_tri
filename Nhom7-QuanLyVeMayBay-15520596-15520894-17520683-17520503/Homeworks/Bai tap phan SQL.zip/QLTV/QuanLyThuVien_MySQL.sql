-- Kai Pa did that

drop database QLTV;
create database QLTV;
use QLTV;

create table DocGia
(
	ma_DocGia smallint primary key,
	ho nvarchar(15),
	tenlot nvarchar(15),
	ten nvarchar(15),
	ngaysinh char(20)
);

create table NguoiLon
(
	sonha nvarchar(15),
	duong nvarchar(63),
	quan nvarchar(20),
	dienthoai nvarchar(10),
	han_sd char(20),
    ma_DocGia smallint primary key,
    constraint FK_nguoilon_docgia foreign key(ma_DocGia) references DocGia(ma_DocGia)
);

create table TreEm
(
	ma_DocGia smallint,
	ma_DocGia_nguoilon smallint,
    primary key(ma_DocGia),
    constraint FK_treem_docgia foreign key(ma_DocGia) references DocGia(ma_DocGia),
    constraint FK_treem_nguoilon foreign key(ma_DocGia_nguoilon) references NguoiLon(ma_DocGia)
);

create table TuaSach
(
	ma_tuasach int primary key,
	tuasach nvarchar(63),
	tacgia nvarchar(31),
	tomtat nvarchar(222)
);

create table DauSach
(
	isbn int primary key,
	ma_tuasach int,
	ngonngu nvarchar(15),
	bia nvarchar(15),
	trangthai nvarchar(1),
	constraint FK_dauSach_TuaSach foreign key(ma_tuasach) references TuaSach(ma_tuasach)
);

create table CuonSach
(
	isbn int,
	ma_cuonsach smallint,
	tinhtrang nvarchar(1),
	primary key(isbn, ma_cuonsach),
    constraint FK_cuonsach_dausach foreign key(isbn) references DauSach(isbn)
);

create table DangKy
(
	isbn int,
	ma_DocGia smallint,
	ngay_dk char(20),
	ghichu nvarchar(255),
	primary key(isbn, ma_DocGia),
    constraint FK_dangki_dauSach foreign key(isbn) references DauSach(isbn),
    constraint FK_dangki_docgia foreign key(ma_DocGia) references DocGia(ma_DocGia)
);

create table Muon
(
	isbn int,
	ma_cuonsach smallint,
	ma_DocGia smallint,
	ngay_muon char(20),
	ngay_hethan char(20),
    
	primary key(isbn, ma_cuonsach),
	constraint FK_muon_cuonsach foreign key(isbn, ma_cuonsach) references CuonSach(isbn, ma_cuonsach),
	constraint FK_muon_docgia foreign key(ma_DocGia) references DocGia(ma_DocGia)
);

create table QuaTrinhMuon
(
	isbn int,
	ma_cuonsach smallint,
	ngay_muon char(20),
	ma_DocGia smallint,
	ngay_hethan char(20),
	ngay_tra char(20),
	tien_muon int,
	tien_datra int,
	tien_datcoc int,
	ghichu nvarchar(255),
    
	primary key(isbn, ma_cuonsach, ngay_muon),
	constraint FK_quatrinhmuon_docgia foreign key(ma_DocGia) references DocGia(ma_DocGia),
	constraint FK_quatrinhmuon_cuonsach foreign key(isbn, ma_cuonsach) references CuonSach(isbn, ma_cuonsach)
)

