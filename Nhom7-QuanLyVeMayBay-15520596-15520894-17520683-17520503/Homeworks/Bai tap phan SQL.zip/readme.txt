﻿
- Nhóm làm bài trên 2 DBMS là SQL Server và MySQL
- Vì data bài QLTV cô cung cấp bị lỗi nên nhóm đã fix lại và có đính kèm trong bài nộp. Cô dùng file data này để check nhé
